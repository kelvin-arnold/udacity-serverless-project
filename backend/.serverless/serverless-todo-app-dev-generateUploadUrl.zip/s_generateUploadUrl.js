
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'karnoldf',
  applicationName: 'serverless-todo-app',
  appUid: '24crn1pg4fy2tQ4kts',
  orgUid: 'ce8db805-f85f-4ceb-bdd4-fda2d3c7b992',
  deploymentUid: '54e44fca-122b-4567-ab0e-d5f1017ccc3d',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-generateUploadUrl', timeout: 6 };

try {
  const userHandler = require('./src/functions/generateUploadUrl/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}