
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'karnoldf',
  applicationName: 'serverless-todo-app',
  appUid: '24crn1pg4fy2tQ4kts',
  orgUid: 'ce8db805-f85f-4ceb-bdd4-fda2d3c7b992',
  deploymentUid: '692342e4-163f-496a-9366-f97835358c2a',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-generateUploadUrl', timeout: 6 };

try {
  const userHandler = require('./src/functions/generateUploadUrl/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}